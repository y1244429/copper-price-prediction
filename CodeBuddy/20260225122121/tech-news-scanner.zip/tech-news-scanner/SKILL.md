---
name: tech-news-scanner
:description: Scan authoritative media and social platforms for tech news from the past 24 hours and generate an HTML report with links. Use this skill when users ask to collect, summarize, or report on recent technology news, tech trends, or hot topics from domestic and international media sources.
---

# Tech News Scanner

## Overview

Scan domestic and international authoritative media and social platforms for technology news from the past 24 hours, then generate a beautifully styled HTML report with direct links to source articles.

## Workflow

### Step 1: Determine Scope

Identify the specific requirements:
- **Time range**: Default is past 24 hours
- **Geographic scope**: Domestic, international, or both
- **Tech domains**: AI, chips, 5G/6G, EVs, metaverse, Web3, cloud computing, etc.
- **Platform focus**: Specific media outlets or social platforms

Ask for clarification if any parameters are unclear.

### Step 2: Search for Tech News

Use the `web_search` tool to gather news from multiple sources. Execute searches in parallel when possible:

**Search Strategy:**
1. Reference `references/media_sources.md` for media lists
2. Combine time constraints + platform + tech keywords
3. Search multiple sources to ensure comprehensive coverage

**Example search queries:**
- "site:36kr.com 人工智能 最新"
- "site:techcrunch.com AI technology today"
- "微博 科技资讯 24小时"
- "site:mittechnologyreview.com artificial intelligence"
- "site:huxiu.com 科技 热点"

Execute searches systematically, grouping by:
- Domestic tech media (36氪, 虎嗅, 钛媒体, etc.)
- International tech media (TechCrunch, The Verge, Wired, etc.)
- Social platforms (微博, X/Twitter, Reddit, etc.)

### Step 3: Process and Organize Results

Collect search results and structure them:

```python
news_data = [
    {
        "title": "News headline",
        "source": "Media platform name",
        "url": "Full URL to article",
        "summary": "Brief 1-2 sentence summary",
        "timestamp": "Publication time",
        "platform": "Platform category (媒体/社交)"
    },
    # ... more items
]
```

**Best practices:**
- Remove duplicate articles (same content from multiple sources)
- Prioritize authoritative sources over rumors
- Include timestamps when available
- Verify URLs are accessible
- Summarize key points concisely

### Step 4: Generate HTML Report

Use `scripts/generate_report.py` to create the report:

```bash
# Prepare JSON data
echo '[{"title":"...","source":"...","url":"...","summary":"...","timestamp":"...","platform":"..."}]' > news.json

# Generate report
python scripts/generate_report.py news.json tech-news-report.html
```

The script will:
- Create a responsive, beautifully styled HTML page
- Include all news items with links
- Add metadata (date, article count, platforms)
- Generate platform badges for each article

### Step 5: Deliver Report

Provide the user with:
1. The generated HTML file path
2. Article summary statistics
3. Option to preview in browser
4. Links to specific articles of interest

Example delivery:
```
✅ 生成了过去24小时科技热点报告
📊 统计：共收集 15 条热点新闻
📁 报告文件：tech-news-report.html

主要热点：
- OpenAI发布新模型GPT-5 (来源：36氪)
- 苹果发布iPhone 17系列 (来源：虎嗅)
- 英伟达新款GPU发布 (来源：TechCrunch)
...
```

## Resources

### scripts/generate_report.py

Python script that generates a professional HTML report from JSON-formatted news data.

**Features:**
- Responsive design with modern styling
- Gradient header with statistics
- Platform badges for source categorization
- Direct links to original articles
- Mobile-friendly layout

**Usage:**
```bash
python scripts/generate_report.py <news_data.json> [output_path]
```

**Input format:** JSON array of news objects with fields: title, source, url, summary, timestamp, platform

### references/media_sources.md

Comprehensive list of authoritative media and social platforms for tech news.

**Contents:**
- Domestic tech media (36氪, 虎嗅, 钛媒体, etc.)
- International tech media (TechCrunch, The Verge, Wired, etc.)
- Social platforms (微博, X/Twitter, Reddit, etc.)
- Tech domain keywords
- Search strategy examples

Use this as a reference for comprehensive source coverage.
