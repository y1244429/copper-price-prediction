# 权威媒体和社交平台列表

## 国内权威媒体

### 科技媒体
- 36氪 (36kr.com) - 科技创投媒体
- 虎嗅 (huxiu.com) - 商业科技资讯
- 钛媒体 (tmtpost.com) - 科技商业媒体
- 爱范儿 (ifanr.com) - 科技生活方式
- 钛度 (tech.qq.com) - 腾讯科技
- 网易科技 (tech.163.com) - 网易科技频道
- 新浪科技 (tech.sina.com.cn) - 新浪科技频道
- 澎湃科技 (thepaper.cn) - 澎湃新闻科技
- 机器之心 (jiqizhixin.com) - AI与前沿科技
- 量子位 (qbitai.com) - 人工智能与前沿科技

### 综合媒体科技版块
- 新华网科技
- 人民日报科技
- 央视新闻科技

## 国外权威媒体

### 科技媒体
- TechCrunch (techcrunch.com)
- The Verge (theverge.com)
- Wired (wired.com)
- Engadget (engadget.com)
- Ars Technica (arstechnica.com)
- MIT Technology Review (technologyreview.com)

### 综合媒体
- Reuters Technology
- Bloomberg Technology
- BBC Technology
- New York Times Technology
- Washington Post Technology

## 社交平台

### 国内平台
- 微博 - #科技#、#科技资讯# 话题
- 知乎 - 科技、互联网、人工智能话题
- 哔哩哔哩 - 科技区、数码区
- 小红书 - 科技数码笔记

### 国际平台
- X (Twitter) - 科技话题
- Reddit - r/technology, r/artificial, r/gadgets
- LinkedIn - 科技行业动态

## 搜索关键词示例

### 科技领域核心关键词
- 人工智能 (AI)
- 机器学习
- 深度学习
- 芯片/半导体
- 5G/6G
- 新能源汽车
- 元宇宙
- Web3/区块链
- 云计算
- 大数据
- 量子计算
- 生物科技
- 医疗科技
- 智能手机
- 操作系统

### 搜索建议
搜索时应组合使用：时间限定（24小时内）+ 平台名称 + 科技关键词

例如：
- "site:36kr.com 人工智能"
- "site:techcrunch.com AI breakthrough"
- "微博 人工智能 过去24小时"
