# 贵金属和石油新闻资讯源列表

## 国内权威财经媒体

### 综合财经媒体
- 新浪财经 (finance.sina.com.cn) - 综合财经资讯
- 网易财经 (money.163.com) - 网易财经频道
- 腾讯财经 (finance.qq.com) - 腾讯财经频道
- 搜狐财经 (business.sohu.com) - 搜狐财经频道
- 东方财富网 (www.eastmoney.com) - 专业财经资讯
- 金融界 (www.jrj.com.cn) - 金融财经门户
- 和讯网 (www.hexun.com) - 财经资讯平台
- 第一财经 (www.yicai.com) - 专业财经媒体
- 财新网 (www.caixin.com) - 财经新闻

### 贵金属专业媒体
- 上海黄金交易所 (www.sge.com.cn) - 官方黄金交易所
- 中国黄金网 (www.gold.org.cn) - 黄金行业资讯
- 黄金宝 (www.huangjinbao.cn) - 黄金投资资讯
- 贵金属网 (www.guijinshu.com) - 贵金属专业平台
- 金投网 (www.cngold.org) - 黄金白银投资资讯

### 商品期货媒体
- 期货日报 (www.qhrb.com.cn) - 期货专业媒体
- 和讯期货 (futures.hexun.com) - 期货资讯
- 世纪金融网 (www.financeun.com) - 期货投资资讯
- 中国期货业协会 (www.cfachina.org) - 行业协会

### 石油能源媒体
- 中国石油新闻中心 (news.cnpc.com.cn) - 中石油新闻
- 中国石化新闻网 (news.sinopecnews.com.cn) - 中石化新闻
- 能源网 (www.china5e.com) - 能源行业资讯
- 石油link (www.oillink.cn) - 石油行业资讯

## 国外权威财经媒体

### 综合财经媒体
- Bloomberg (bloomberg.com) - 彭博社财经资讯
- Reuters (reuters.com) - 路透社财经新闻
- CNBC (cnbc.com) - CNBC财经频道
- Wall Street Journal (wsj.com) - 华尔街日报
- Financial Times (ft.com) - 金融时报

### 贵金属专业媒体
- Kitco (www.kitco.com) - 全球贵金属权威资讯
- Gold.org (www.gold.org) - 世界黄金协会
- Silver Institute (www.silverinstitute.org) - 白银协会
- London Metal Exchange (www.lme.com) - 伦敦金属交易所
- CME Group (www.cmegroup.com) - 芝加哥商品交易所

### 石油能源媒体
- Oil Price (oilprice.com) - 石油价格资讯
- Energy News (energynews.com) - 能源新闻
- Platts (www.platts.com) - 普氏能源资讯
- IEA (www.iea.org) - 国际能源署
- OPEC (www.opec.org) - 石油输出国组织

## 社交平台

### 国内平台
- 微博 - #黄金#、#白银#、#石油#、#期货# 话题
- 知乎 - 贵金属、投资、经济金融话题
- 哔哩哔哩 - 财经、投资、期货分析
- 小红书 - 黄金投资、理财笔记

### 国际平台
- X (Twitter) - Gold, Silver, Oil, Commodities tags
- Reddit - r/preciousmetals, r/silverbugs, r/oil
- LinkedIn - Commodities, Trading, Investment

## 主要商品指数和交易所

### 国内
- 上海期货交易所 (SHFE) - 铜、黄金、白银
- 上海黄金交易所 (SGE) - 黄金、白银
- 大连商品交易所 (DCE) - 焦炭、焦煤、铁矿石
- 郑州商品交易所 (CZCE) - PTA、甲醇、玻璃

### 国际
- 纽约商品交易所 (COMEX) - 黄金、白银
- 伦敦金属交易所 (LME) - 铜
- 纽约商业交易所 (NYMEX) - 石油
- 洲际交易所 (ICE) - 布伦特石油

## 搜索关键词示例

### 贵金属
- 黄金价格、现货黄金、黄金期货
- 白银价格、现货白银、白银走势
- 黄金ETF、黄金投资、避险资产
- 通胀、利率、美元指数

### 有色金属
- 铜价、LME铜、沪铜
- 伦敦金属交易所、有色金属
- 中国需求、制造业PMI
- 供应链、贸易数据

### 石油
- 国际油价、布伦特原油、WTI原油
- OPEC+减产、石油产量
- 地缘政治、中东局势
- EIA库存、API库存
- 新能源转型、能源需求

### 搜索建议
搜索时应组合使用：时间限定（24小时内）+ 平台名称 + 商品关键词

例如：
- "site:finance.sina.com.cn 黄金 今日"
- "site:kitco.com gold news today"
- "微博 石油 24小时"
- "site:bloomberg.com oil prices"
- "site:gold.org 黄金市场 最新"
