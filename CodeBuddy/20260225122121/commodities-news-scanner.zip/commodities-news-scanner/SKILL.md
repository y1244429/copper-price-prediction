---
name: commodities-news-scanner
:description: Scan authoritative media and financial platforms for precious metals (gold, silver, copper) and oil news from the past 24 hours and generate an HTML report with links. Use this skill when users ask to collect, summarize, or report on recent commodities news, gold/silver prices, copper markets, or oil industry updates from domestic and international media sources.
---

# Commodities News Scanner

## Overview

Scan domestic and international authoritative financial media and platforms for precious metals (gold, silver, copper) and oil news from the past 24 hours, then generate a beautifully styled HTML report with direct links to source articles.

## Workflow

### Step 1: Determine Scope

Identify the specific requirements:
- **Time range**: Default is past 24 hours
- **Geographic scope**: Domestic, international, or both
- **Commodities focus**: Gold, silver, copper, oil, or combination
- **Platform focus**: Specific media outlets or financial platforms

Ask for clarification if any parameters are unclear.

### Step 2: Search for Commodities News

Use the `web_search` tool to gather news from multiple sources. Execute searches in parallel when possible:

**Search Strategy:**
1. Reference `references/sources.md` for comprehensive media lists
2. Combine time constraints + platform + commodity keywords
3. Search multiple sources to ensure comprehensive coverage

**Example search queries:**

**Gold (黄金):**
- "site:finance.sina.com.cn 黄金 今日"
- "site:kitco.com gold news today"
- "site:gold.org 黄金市场 最新"

**Silver (白银):**
- "site:finance.sina.com.cn 白银 走势"
- "site:kitco.com silver prices today"
- "白银 ETF 最新消息"

**Copper (铜):**
- "site:finance.sina.com.cn 铜价 今日"
- "site:lme.com copper prices"
- "site:bloomberg.com copper market"

**Oil (石油):**
- "site:finance.sina.com.cn 国际油价"
- "site:oilprice.com oil news"
- "OPEC+ 石油 产量"

**General commodities:**
- "大宗商品 热点 24小时"
- "commodities news today gold silver oil"
- "site:bloomberg.com commodities"

Execute searches systematically, grouping by:
- **Domestic financial media** (新浪财经、东方财富、和讯网, etc.)
- **International financial media** (Bloomberg, Reuters, CNBC, etc.)
- **Precious metals specialists** (Kitco, Gold.org, etc.)
- **Energy specialists** (Oil Price, Platts, etc.)
- **Social platforms** (微博, X/Twitter, Reddit, etc.)

### Step 3: Process and Organize Results

Collect search results and structure them:

```python
news_data = [
    {
        "title": "News headline",
        "source": "Media platform name",
        "url": "Full URL to article",
        "summary": "Brief 1-2 sentence summary",
        "timestamp": "Publication time",
        "category": "Commodity category (黄金/白银/铜/石油)"
    },
    # ... more items
]
```

**Best practices:**
- Remove duplicate articles (same content from multiple sources)
- Prioritize authoritative sources over rumors
- Include timestamps when available
- Verify URLs are accessible
- Summarize key price movements, market drivers, and news impacts
- Categorize accurately by commodity type (黄金/白银/铜/石油)

### Step 4: Generate HTML Report

Use `scripts/generate_report.py` to create the report:

```bash
# Prepare JSON data
echo '[{"title":"...","source":"...","url":"...","summary":"...","timestamp":"...","category":"..."}]' > commodities_news.json

# Generate report
python scripts/generate_report.py commodities_news.json commodities-news-report.html
```

The script will:
- Create a responsive, beautifully styled HTML page with dark theme
- Include all news items with links
- Add metadata (date, article count, category breakdown)
- Generate category-specific badges (gold/silver/copper/oil) for each article
- Support Chinese and English content

### Step 5: Deliver Report

Provide the user with:
1. The generated HTML file path
2. Article summary statistics by category
3. Key market insights and trends
4. Option to preview in browser
5. Links to specific articles of interest

Example delivery:
```
✅ 生成了过去24小时贵金属和石油热点报告
📊 统计：共收集 18 条热点新闻
   - 黄金: 5条
   - 白银: 3条
   - 铜: 4条
   - 石油: 6条

📁 报告文件：commodities-news-report.html

主要热点：
- 国际金价突破2000美元大关 (来源：Kitco)
- 白银ETF持仓量创历史新高 (来源：新浪财经)
- 铜价受中国需求推动上涨 (来源：Bloomberg)
- OPEC+宣布延长减产协议 (来源：Oil Price)
...
```

## Resources

### scripts/generate_report.py

Python script that generates a professional HTML report from JSON-formatted news data.

**Features:**
- Dark gradient theme with modern styling
- Category-specific color badges (gold/silver/copper/oil)
- Responsive design with mobile-friendly layout
- Statistics breakdown by commodity type
- Direct links to original articles
- Support for mixed Chinese/English content

**Usage:**
```bash
python scripts/generate_report.py <commodities_data.json> [output_path]
```

**Input format:** JSON array of news objects with fields: title, source, url, summary, timestamp, category

**Category field values:** Use one of: 黄金, 白银, 铜, 石油

### references/sources.md

Comprehensive list of authoritative financial media and platforms for commodities news.

**Contents:**
- Domestic financial media (新浪财经、东方财富、和讯网, etc.)
- International financial media (Bloomberg, Reuters, CNBC, etc.)
- Precious metals specialists (Kitco, Gold.org, Shanghai Gold Exchange, etc.)
- Energy specialists (Oil Price, Platts, IEA, etc.)
- Commodity exchanges (LME, COMEX, NYMEX, etc.)
- Social platforms (微博, X/Twitter, Reddit, etc.)
- Commodity-specific keywords and search strategies

Use this as a reference for comprehensive source coverage across all major commodities.
