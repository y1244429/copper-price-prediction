#!/usr/bin/env python3
"""
Commodities News HTML Report Generator
Generates HTML reports for commodities (gold, silver, copper, oil) news from collected data
"""

import json
import sys
from datetime import datetime
from pathlib import Path


def generate_html_report(news_data, output_path="commodities-news-report.html"):
    """
    Generate an HTML report from news data.

    Args:
        news_data: List of news items with structure:
            {
                "title": str,
                "source": str,
                "url": str,
                "summary": str,
                "timestamp": str,
                "category": str (e.g., "黄金", "白银", "铜", "石油")
            }
        output_path: Path to save the HTML file
    """
    # Get current date for the report
    current_date = datetime.now().strftime("%Y年%m月%d日 %H:%M")

    # Count by category
    category_counts = {}
    for item in news_data:
        category = item.get('category', '其他')
        category_counts[category] = category_counts.get(category, 0) + 1

    # Create category badges HTML
    category_badges = ""
    for category, count in category_counts.items():
        category_badges += f"""
        <div class="stat">
            <div class="number">{count}</div>
            <div class="label">{category}</div>
        </div>"""

    html_template = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>贵金属和石油热点事件报告</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            padding: 20px;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}

        .header {{
            background: white;
            border-radius: 12px;
            padding: 40px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            text-align: center;
        }}

        .header h1 {{
            font-size: 2.5rem;
            color: #1a1a1a;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #f39c12 0%, #e74c3c 50%, #3498db 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }}

        .header .date {{
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 5px;
        }}

        .header .subtitle {{
            color: #999;
            font-size: 0.9rem;
        }}

        .stats {{
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 20px;
            flex-wrap: wrap;
        }}

        .stat {{
            text-align: center;
        }}

        .stat .number {{
            font-size: 2rem;
            font-weight: bold;
            color: #1a1a2e;
        }}

        .stat .label {{
            color: #666;
            font-size: 0.9rem;
        }}

        .content {{
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }}

        .news-item {{
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 25px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }}

        .news-item:hover {{
            border-color: #1a1a2e;
            box-shadow: 0 4px 12px rgba(26, 26, 46, 0.15);
        }}

        .news-item:last-child {{
            margin-bottom: 0;
        }}

        .news-header {{
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }}

        .news-title {{
            font-size: 1.4rem;
            font-weight: 600;
            color: #1a1a1a;
            flex: 1;
            min-width: 300px;
        }}

        .news-meta {{
            display: flex;
            gap: 12px;
            align-items: center;
        }}

        .badge {{
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }}

        .badge.gold {{
            background: #fff8e1;
            color: #f39c12;
        }}

        .badge.silver {{
            background: #f5f5f5;
            color: #7f8c8d;
        }}

        .badge.copper {{
            background: #ffebee;
            color: #e74c3c;
        }}

        .badge.oil {{
            background: #e8f5e9;
            color: #27ae60;
        }}

        .badge.source {{
            background: #e3f2fd;
            color: #1976d2;
        }}

        .news-summary {{
            color: #555;
            line-height: 1.8;
            margin-bottom: 15px;
        }}

        .news-footer {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid #e0e0e0;
        }}

        .news-time {{
            color: #999;
            font-size: 0.9rem;
        }}

        .news-link {{
            display: inline-block;
            padding: 10px 20px;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 500;
            transition: transform 0.2s ease;
        }}

        .news-link:hover {{
            transform: translateY(-2px);
        }}

        .footer {{
            text-align: center;
            margin-top: 20px;
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
        }}

        @media (max-width: 768px) {{
            .header h1 {{
                font-size: 1.8rem;
            }}

            .stats {{
                gap: 15px;
            }}

            .news-title {{
                min-width: 200px;
            }}

            .news-header {{
                flex-direction: column;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💰 贵金属和石油热点事件报告</h1>
            <div class="date">📅 {current_date}</div>
            <div class="subtitle">过去24小时内黄金、白银、铜、石油等重要大宗商品动态</div>
            <div class="stats">
                <div class="stat">
                    <div class="number">{len(news_data)}</div>
                    <div class="label">热点事件</div>
                </div>
{category_badges}
            </div>
        </div>

        <div class="content">
"""

    for item in news_data:
        # Determine badge class based on category
        category = item.get('category', '其他')
        category_lower = category.lower()
        badge_class = 'source'
        if '黄金' in category or 'gold' in category_lower:
            badge_class = 'gold'
        elif '白银' in category or 'silver' in category_lower:
            badge_class = 'silver'
        elif '铜' in category or 'copper' in category_lower:
            badge_class = 'copper'
        elif '石油' in category or 'oil' in category_lower:
            badge_class = 'oil'

        html_template += f"""
            <div class="news-item">
                <div class="news-header">
                    <h2 class="news-title">{item['title']}</h2>
                    <div class="news-meta">
                        <span class="badge {badge_class}">{item['category']}</span>
                        <span class="badge source">{item['source']}</span>
                    </div>
                </div>
                <p class="news-summary">{item['summary']}</p>
                <div class="news-footer">
                    <span class="news-time">⏰ {item['timestamp']}</span>
                    <a href="{item['url']}" class="news-link" target="_blank">📖 阅读原文</a>
                </div>
            </div>
"""

    html_template += f"""
        </div>

        <div class="footer">
            <p>🤖 本报告由 AI 自动生成 | 数据来源：各大权威财经媒体和资讯平台</p>
        </div>
    </div>
</body>
</html>
"""

    # Write to file
    output_file = Path(output_path)
    output_file.write_text(html_template, encoding='utf-8')

    print(f"✅ HTML报告已生成: {output_file.absolute()}")
    return str(output_file.absolute())


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python generate_report.py <json_data_file> [output_path]")
        print("Or pipe JSON data: cat news.json | python generate_report.py")
        sys.exit(1)

    input_file = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else "commodities-news-report.html"

    # Read input data
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            news_data = json.load(f)
    except FileNotFoundError:
        print(f"❌ 错误: 文件不存在 - {input_file}")
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"❌ 错误: JSON格式错误 - {input_file}")
        sys.exit(1)

    # Generate report
    generate_html_report(news_data, output_path)
